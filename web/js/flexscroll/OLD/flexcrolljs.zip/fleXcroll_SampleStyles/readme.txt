fleXcroll CANNOT be used in commercial sites, or commercially built sites
without a commercial license registered to the user's name. For details
about licensing please visit www.hesido.com, or email me at:
emrahbaskaya at hesido dot com

-------------------------
About fleXcroll example styles:
The HTML, the CSS and the script file is best viewed using a proper text editor.
All .js files are the same, differences are made using CSS, and sometimes HTML.

You can find the non-compressed, readable version of the fleXcroll script inside the folder:
recommended_styles/fullimage-commented-uncompressed
The other examples contain a compressed version of the script for faster loading.


I prefer to use Scintilla text editor for my CSS, HTML, and script codings:
http://scintilla.sourceforge.net/SciTE.html

All questions regarding fleXcroll can be directed to me:
emrahbaskaya at hesido dot com
-------------------------

Content of the archive can be seen in content.htm in the root of the archive.
